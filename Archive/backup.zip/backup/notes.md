# execute

    minikube start
    minikube status
    kubectl cluster-info


    kubectl apply -f client-pod.yaml
    kubectl apply -f client-node-port.yaml
    kubectl get pods
    kubectl get services

    minikube ip
    kubectl cluster-info

# access

    http://192.168.64.3:31515/

# change declaration

    <!-- update yaml file -->

# get pod/service information

    kubectl describe <object_type> <object_name>
    kubectl describe pod client-pod

# get rid of pod

    kubectl delete -f <config_file>
    kubectl get pods

# deployment

    kubectl apply -f client-deployment.yaml
    kubectl get pods
    kubectl get deployments
    minikube ip
    kubectl get pods -o wide
    kubectl describe pods

# refresh image

    kubectl set image <object_type>/<object_name> <container_name> = <new_image>

    kubectl set image deployment/client-deployment client=stephengrider/multi-client:v5

# reconfigure docker-cli

    <!-- Temporary Connection Only-->
    eval $(minikube docker-env)
    docker ps
    docker kill b8f5e140570a
    docker get pods

### stuff to with docker-cli reconfigured

    docker exec -it b8f5e140570a sh
        <!-- kubectl exec -it client-deployment-545b694544-qc5l5 sh -->

    docker logs b8f5e140570a
        <!-- kubectl get pods
        kubectl logs client-deployment-545b694544-qc5l5 -->

    docker system prune -a
